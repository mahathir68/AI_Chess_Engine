
import random


pieceScore = {"K":0,"Q":10,"R":5,"B":3,"N":3,"p":1} # create scores for each piece, king is 0 as it is not capture only checkmate
CHECKMATE = 1000
STALEMATE = 0
  #if positve value of score then white is winning
  #if negative value of score then black is winning

def findRandomMove(validMoves):
    return validMoves[random.randint(0,len(validMoves)-1)] #any random valid move index in validMove list for a piece is assigned to validmoves and then that index is called



def findBestMove(gs,validMoves):
    turnMultiplier = 1 if gs.whiteToMove else -1 #if white turnmultiplier is 1 if black it would be -1

    opponentMinmaxScore = CHECKMATE # choosing the Minimum of the maximum score that a white can get if AI moves
     #so start from the best score of white and decrease from that for minimum

    bestPlayerMove = None # what would be the best move for white
    random.shuffle(validMoves) # shuffle the valid moves AI can make at first

    for playerMove in validMoves:
        gs.makeMove(playerMove)
        #score = turnMultiplier*scoreMaterial(gs.board) #determine whose turn it is by turn multiplier and multiply with score gained to get actual score of current player
        opponentsMoves = gs.getValidMoves() #get the possible valid moves white can make to predict the best move for AI
        opponentMaxScore = -CHECKMATE # get the opponents maximum score at a game state to compare with the new max

        for opponentsMove in opponentsMoves: #how many valid moves are possible from opponent
            gs.makeMove(opponentsMove) #make the opponent move to examine
            if gs.checkMate:
                score = -turnMultiplier*CHECKMATE #if white can cause checkmate
                #check if white/opponent can cause checkmate
            elif gs.staleMate:
                score = STALEMATE
            else:
                score = -turnMultiplier*scoreMaterial(gs.board) #check the score of white at current state
            if score > opponentMaxScore: #start from worst, if current score of opponent/white greater then opponent's worst score
                opponentMaxScore = score # then select opponentMax score as score
            gs.undoMove() # revert back to previous game state as analyzing is done
        if opponentMaxScore < opponentMinmaxScore: #if the new maximum is less than the previous maximum
            #it is better for AI to take the square defined by the previous maximum move by opponent
            opponentMinmaxScore = opponentMaxScore
            bestPlayerMove = playerMove #best move by AI
        gs.undoMove() # it is done cz first AI had to move to get whites potential move so white had to move to get score of white
        #now both undo to gain best possible playerMove by AI


    return bestPlayerMove   # and to calculate best move so that it can be made

def scoreMaterial(board): #score calculation
    score = 0 #score 0 for any player
    for row in board:
        for square in row:
            if square[0]=="w": #color of square piece
                score += pieceScore[square[1]] #the captured item's piece score will be added to white player score
            elif square[0] == "b":
                score -= pieceScore[square[1]] # the second index of square is piece type
    return score

